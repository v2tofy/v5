(() => {
    let selectionRange = null;
    let lastAnswerElement = null;
    let hideTimeout = null;

    // Handle text selection
    function handleTextSelection(e) {
        try {
            const selection = window.getSelection();
            if (!selection || !selection.rangeCount) return;

            const selectedText = selection.toString().trim();
            
            if (selectedText.length > 10) {
                selectionRange = selection.getRangeAt(0).cloneRange();
                getAnswer(selectedText);
            }
        } catch (err) {
            console.error('Error in selection handler:', err);
        }
    }

    // Get answer from background script
    function getAnswer(question) {
        if (!selectionRange || !question.trim()) return;
        
        // Clear any existing timeout and remove previous answer
        if (hideTimeout) {
            clearTimeout(hideTimeout);
        }
        if (lastAnswerElement) {
            lastAnswerElement.remove();
        }
        
        chrome.runtime.sendMessage({
            action: 'getAnswer',
            question: question.trim()
        }, response => {
            try {
                if (!response) return;
                
                const text = response.answer || response.error || '';
                if (text.trim()) {
                    insertText(text.trim());
                }
            } catch (err) {
                console.error('Error processing answer:', err);
            }
        });
    }

    // Insert text at selection
    function insertText(text) {
        try {
            if (!text || !selectionRange) return;
            
            const selection = window.getSelection();
            if (!selection) return;
            
            // Create a span for the answer
            const answerSpan = document.createElement('span');
            answerSpan.textContent = text;
            
            // Insert the span
            selectionRange.collapse(false);
            selectionRange.insertNode(answerSpan);
            
            // Store reference to current answer element
            lastAnswerElement = answerSpan;
            
            // Clean up
            selection.removeAllRanges();
            
            // Set timeout to remove the answer after 5 seconds
            hideTimeout = setTimeout(() => {
                answerSpan.remove();
                lastAnswerElement = null;
            }, 5000);
            
        } catch (err) {
            console.error('Error inserting text:', err);
        }
    }

    // Add event listener for text selection
    // Error reporting function
    function reportError(error) {
        console.error(error);
        const errorSpan = document.createElement('span');
        errorSpan.style.color = 'red';
        errorSpan.style.position = 'fixed';
        errorSpan.style.bottom = '10px';
        errorSpan.style.right = '10px';
        errorSpan.style.padding = '10px';
        errorSpan.style.background = 'white';
        errorSpan.style.border = '1px solid red';
        errorSpan.style.borderRadius = '4px';
        errorSpan.style.zIndex = '9999';
        errorSpan.textContent = error.message || 'An error occurred';
        document.body.appendChild(errorSpan);
        setTimeout(() => errorSpan.remove(), 5000);
    }

    // Add error handling to message sending
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.error) {
            reportError(new Error(message.error));
        }
    });

    document.addEventListener('mouseup', handleTextSelection);
})();
