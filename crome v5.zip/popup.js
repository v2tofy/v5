document.addEventListener('DOMContentLoaded', function() {
    // Load saved API key when popup opens
    chrome.storage.sync.get(['apiKey'], result => {
        if (result.apiKey) {
            document.getElementById('apiKey').value = result.apiKey;
        }
    });

    // Save API key
    document.getElementById('saveKey').addEventListener('click', function() {
        const apiKey = document.getElementById('apiKey').value.trim();
        chrome.storage.sync.set({ apiKey: apiKey }, () => {
            showStatus('API key saved successfully!', 'success');
        });
    });

    // Reset to default key
    document.getElementById('resetKey').addEventListener('click', function() {
        document.getElementById('apiKey').value = '';
        chrome.storage.sync.remove('apiKey', () => {
            showStatus('Reset to default API key', 'success');
        });
    });
});

// Show status message
function showStatus(message, type) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = 'status ' + type;
    status.style.display = 'block';
    
    // Hide message after 3 seconds
    setTimeout(() => {
        status.style.display = 'none';
    }, 3000);
}
