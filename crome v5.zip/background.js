const DEFAULT_API_KEY = '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';
const BACKUP_API_KEY_1 = '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';
const BACKUP_API_KEY_2 = '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';
const API_URL = 'https://openrouter.ai/api/v1/chat/completions';

// Get current API key (custom or default)
async function getCurrentApiKey() {
    try {
        const result = await chrome.storage.sync.get(['apiKey']);
        return result.apiKey || DEFAULT_API_KEY;
    } catch (error) {
        console.error('Error getting API key:', error);
        return DEFAULT_API_KEY;
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getAnswer') {
        fetchAnswer(request.question)
            .then(answer => sendResponse({ answer }))
            .catch(error => sendResponse({ error: error.message }));
        return true; // Will respond asynchronously
    }
});

async function fetchAnswer(question) {
    const apiKeys = [
        await getCurrentApiKey(),
        BACKUP_API_KEY_1,
        BACKUP_API_KEY_2
    ];

    let lastError = null;
    for (const apiKey of apiKeys) {
        try {
            console.log('Attempting API request with key:', apiKey.substring(0, 10) + '...');
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`,
                    'HTTP-Referer': chrome.runtime.getURL('/'),
                    'X-Title': 'Test Answer Helper Extension'
                },
                body: JSON.stringify({
                    model: 'mistralai/mistral-7b-instruct',
                    messages: [
                        {
                            role: 'system',
                            content: 'You are an expert test answering assistant. Your task is to provide ONLY the correct answer without any explanations or additional text. If it is a multiple choice question, just state the correct option (A, B, C, or D). If it is a text-based question, provide only the direct answer in the shortest possible form. Do not include any explanations, reasoning, or additional context.'
                        },
                        {
                            role: 'user',
                            content: `Provide only the correct answer for this question:\n\n${question}`
                        }
                    ],
                    temperature: 0.3,
                    max_tokens: 300,
                    top_p: 0.9
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('API Error Response:', errorText);
                try {
                    const errorData = JSON.parse(errorText);
                    if (response.status === 401) {
                        throw new Error('Invalid API key.');
                    } else if (response.status === 429) {
                        throw new Error('Too many requests.');
                    } else if (response.status >= 500) {
                        throw new Error('Server is temporarily unavailable.');
                    } else if (errorData.error?.message) {
                        throw new Error(errorData.error.message);
                    } else {
                        throw new Error('Failed to get an answer.');
                    }
                } catch (e) {
                    if (e.message.includes('API key')) {
                        throw e;
                    }
                    throw new Error('Connection error.');
                }
            }

            const data = await response.json();
            console.log('API Response:', data);
            
            if (data.choices && data.choices[0] && data.choices[0].message) {
                return formatAnswer(data.choices[0].message.content);
            } else {
                throw new Error('No answer received from API');
            }
        } catch (error) {
            console.error('API attempt failed:', error);
            lastError = error;
            // Continue to next API key
            continue;
        }
    }
    
    // If we get here, all API keys failed
    throw lastError || new Error('All API attempts failed');
}

function formatAnswer(answer) {
  if (!answer) return '';
  return answer
    .trim()
    .replace(/^(Answer:|The answer is:|The correct answer is:|Result:|Solution:|The solution is:)/gi, '')
    .replace(/[\n\r]+/g, ' ')  // Replace newlines with spaces
    .replace(/\s+/g, ' ')      // Replace multiple spaces with single space
    .trim();
}
