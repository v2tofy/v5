const DEFAULT_API_KEY = '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';
const API_URL = 'https://openrouter.ai/api/v1/chat/completions';

// Get current API key (custom or default)
async function getCurrentApiKey() {
    try {
        const result = await browser.storage.sync.get(['apiKey']);
        return result.apiKey || DEFAULT_API_KEY;
    } catch (error) {
        console.error('Error getting API key:', error);
        return DEFAULT_API_KEY;
    }
}

browser.runtime.onMessage.addListener((request, sender) => {
    if (request.action === 'getAnswer') {
        return fetchAnswer(request.question)
            .then(answer => ({ answer }))
            .catch(error => ({ error: error.message }));
    }
});

async function fetchAnswer(question) {
  try {
    console.log('Making API request to:', API_URL);
    const apiKey = await getCurrentApiKey();
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'HTTP-Referer': browser.runtime.getURL('/'),
        'X-Title': 'Test Answer Helper Extension'
      },
      body: JSON.stringify({
        model: 'mistralai/mistral-7b-instruct',
        messages: [
          {
            role: 'system',
            content: 'You are an expert test answering assistant. Your task is to provide ONLY the correct answer without any explanations or additional text. If it is a multiple choice question, just state the correct option (A, B, C, or D). If it is a text-based question, provide only the direct answer in the shortest possible form. Do not include any explanations, reasoning, or additional context.'
          },
          {
            role: 'user',
            content: `Provide only the correct answer for this question:\n\n${question}`
          }
        ],
        temperature: 0.3, // Lower temperature for more consistent answers
        max_tokens: 300,
        top_p: 0.9
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error Response:', errorText);
      try {
        const errorData = JSON.parse(errorText);
        // Handle common error cases
        if (response.status === 401) {
          throw new Error('Invalid API key.');
        } else if (response.status === 429) {
          throw new Error('Too many requests.');
        } else if (response.status >= 500) {
          throw new Error('Server is temporarily unavailable.');
        } else if (errorData.error?.message) {
          throw new Error(errorData.error.message);
        } else {
          throw new Error('Failed to get an answer.');
        }
      } catch (e) {
        if (e.message.includes('API key')) {
          throw e;
        }
        throw new Error('Connection error.');
      }
    }

    const data = await response.json();
    console.log('API Response:', data);
    
    if (data.choices && data.choices[0] && data.choices[0].message) {
      return formatAnswer(data.choices[0].message.content);
    } else {
      throw new Error('No answer received from API');
    }
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

function formatAnswer(answer) {
  if (!answer) return '';
  return answer
    .trim()
    .replace(/^(Answer:|The answer is:|The correct answer is:|Result:|Solution:|The solution is:)/gi, '')
    .replace(/[\n\r]+/g, ' ')  // Replace newlines with spaces
    .replace(/\s+/g, ' ')      // Replace multiple spaces with single space
    .trim();
}
