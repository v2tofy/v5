document.addEventListener('DOMContentLoaded', function() {
    // Load saved API key when popup opens
    browser.storage.sync.get(['apiKey']).then(result => {
        if (result.apiKey) {
            document.getElementById('apiKey').value = result.apiKey;
        }
    });

    // Save API key
    document.getElementById('saveKey').addEventListener('click', function() {
        const apiKey = document.getElementById('apiKey').value.trim();
        browser.storage.sync.set({ apiKey: apiKey }).then(() => {
            showStatus('API key saved successfully!', 'success');
        });
    });

    // Reset to default key
    document.getElementById('resetKey').addEventListener('click', function() {
        document.getElementById('apiKey').value = '';
        browser.storage.sync.remove('apiKey').then(() => {
            showStatus('Reset to default API key', 'success');
        });
    });
});

// Show status message
function showStatus(message, type) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = 'status ' + type;
    status.style.display = 'block';
    
    // Hide message after 3 seconds
    setTimeout(() => {
        status.style.display = 'none';
    }, 3000);
}
